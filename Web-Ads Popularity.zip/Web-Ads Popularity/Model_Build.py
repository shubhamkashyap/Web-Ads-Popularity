
#importing libraries
import pandas as pd
import pickle as pkl
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

#import dataset
data=pd.read_csv("../Web-Ads Popularity/advertising.csv")

#dropping string variables
data=data.drop(['Ad Topic Line','City','Country','Timestamp'],axis=1)

#separating target variable from dataset
x= data.drop(['Clicked on Ad'],axis = 1)
y= data['Clicked on Ad']
#splitting dataset to train and test set(test size =30%).
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3)
#storing train and test data into csv files
x_train.to_csv('Train_Data.csv',encoding='utf-8',index=False)
x_test.to_csv('Test_Data.csv',encoding='utf-8',index=False)
y_test= pd.DataFrame(y_test)
y_test.to_csv('y_test.csv',encoding='utf-8',index=False)

#Building model using logistic regression
model = LogisticRegression()
model.fit(x_train,y_train)
#Saving model using pickle
filename = 'model.sav'
pkl.dump(model, open(filename, 'wb'))

