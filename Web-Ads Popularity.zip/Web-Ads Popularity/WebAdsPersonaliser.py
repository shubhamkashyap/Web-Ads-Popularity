
#import libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import pickle as pkl
get_ipython().run_line_magic('matplotlib', 'inline')

#read dataset
data=pd.read_csv("../Web-Ads Popularity/advertising.csv")
data.head()

#plot histogram of various features
data.hist(bins=50, figsize=(20,15))
plt.show()

#plot scatter plot between  Area Income Vs Clicked on Ad
plt.scatter(data['Area Income'],data['Clicked on Ad'],alpha=0.05)
plt.xlabel("Area Income ")
plt.ylabel("Clicked on Ad")

#pairplot of each numerical column with other numerical column
sns.pairplot(data)

#scatterplot of "Daily Time Spent on Site" vs "Daily Internet Usage" with repect to  target variable "Clicked on Ad"
sns.scatterplot(x=data['Daily Time Spent on Site'],y=data['Daily Internet Usage'],hue=data['Clicked on Ad'])

#scatterplot of "Age" vs "Daily Time Spent on Site" with repect to  target variable "Clicked on Ad"
sns.scatterplot(x=data['Age'],y=data['Daily Time Spent on Site'],hue=data['Clicked on Ad'])


#import sklearn metrics for classification model
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import roc_curve
from pandas import Timestamp


#import test data and its actual label values
x_test=pd.read_csv("../Web-Ads Popularity/Test_Data.csv")
y_test=pd.read_csv("../Web-Ads Popularity/y_test.csv")
#load model using pickle and predict
filename = 'model.sav'
model = pickle.load(open(filename, 'rb'))
y_pred = model.predict(x_test)

#print accuracy and confusion matrix
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy: %.2f%%" % (accuracy * 100.0))
confusion_matrix(y_test, y_pred)

#classification report
print(classification_report(y_test,y_pred))

#Plotting ROC curve
fpr, tpr, _ = roc_curve(y_test, y_pred)
from ggplot import *
df = pd.DataFrame(dict(fpr=fpr, tpr=tpr))
ggplot(df, aes(x='fpr', y='tpr')) + geom_line() + geom_abline(linetype='dashed')
